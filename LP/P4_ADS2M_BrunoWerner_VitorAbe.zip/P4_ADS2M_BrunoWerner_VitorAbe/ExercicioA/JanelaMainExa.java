package p4.ExercicioA;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JanelaMainExa {

    private JFrame frame;
    private JTextField txtNumero;
    private JLabel lblResultado;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    JanelaMainExa window = new JanelaMainExa();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public JanelaMainExa() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 540, 270);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblNumero = new JLabel("Numero:");
        lblNumero.setBounds(199, 73, 64, 24);
        frame.getContentPane().add(lblNumero);

        txtNumero = new JTextField();
        txtNumero.setBounds(273, 76, 86, 20);
        frame.getContentPane().add(txtNumero);
        txtNumero.setColumns(10);

        JButton btnPerfeito = new JButton("Perfeito");
        btnPerfeito.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                verificarNumeroPerfeito();
            }
        });
        btnPerfeito.setBounds(83, 132, 89, 23);
        frame.getContentPane().add(btnPerfeito);

        JButton btnDSU = new JButton("DSU");
        btnDSU.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcularDSU();
            }
        });
        btnDSU.setBounds(174, 132, 89, 23);
        frame.getContentPane().add(btnDSU);

        JButton btnLimpar = new JButton("Limpar");
        btnLimpar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limparCampos();
            }
        });
        btnLimpar.setBounds(264, 132, 89, 23);
        frame.getContentPane().add(btnLimpar);

        JButton btnSair = new JButton("Sair");
        btnSair.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        btnSair.setBounds(355, 132, 89, 23);
        frame.getContentPane().add(btnSair);

        lblResultado = new JLabel("");
        lblResultado.setBounds(10, 100, 414, 14);
        frame.getContentPane().add(lblResultado);
    }

    private void verificarNumeroPerfeito() {
        try {
            int numero = Integer.parseInt(txtNumero.getText());
            if (numero < 1) {
                throw new NumberFormatException();
            }
            int soma = 0;
            for (int i = 1; i < numero; i++) {
                if (numero % i == 0) {
                    soma += i;
                }
            }
            if (soma == numero) {
                lblResultado.setText(numero + " e um numero perfeito.");
            } else {
                lblResultado.setText(numero + " nao e um numero perfeito.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Por favor, insira um numero valido.");
        }
    }

    private void calcularDSU() {
        try {
            int numero = Integer.parseInt(txtNumero.getText());
            if (numero < 10 || numero > 99) {
                throw new NumberFormatException();
            }
            int D = numero / 10;
            int U = numero % 10;
            int S = D + U;
            lblResultado.setText(D + "" + S + "" + U);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Por favor, insira um numero entre 10 e 99.");
        }
    }

    private void limparCampos() {
        txtNumero.setText("");
        lblResultado.setText("");
    }
}
