package p4.ExercicioB;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogintelaExb extends JFrame {
    private JTextField campoUsuario;
    private JPasswordField campoSenha;

    public LogintelaExb() {
        setTitle("Login");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel lblUsuario = new JLabel("Usuário:");
        lblUsuario.setBounds(10, 10, 80, 25);
        getContentPane().add(lblUsuario);

        campoUsuario = new JTextField();
        campoUsuario.setBounds(100, 10, 160, 25);
        getContentPane().add(campoUsuario);

        JLabel lblSenha = new JLabel("Senha:");
        lblSenha.setBounds(10, 40, 80, 25);
        getContentPane().add(lblSenha);

        campoSenha = new JPasswordField();
        campoSenha.setBounds(100, 40, 160, 25);
        getContentPane().add(campoSenha);

        JButton btnLogin = new JButton("Login");
        btnLogin.setBounds(10, 80, 250, 25);
        getContentPane().add(btnLogin);

        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();
                String senha = new String(campoSenha.getPassword());

                if ("admin".equals(usuario) && "123456".equals(senha)) {
                    TarefasTelaExb tarefasTela = new TarefasTelaExb();
                    tarefasTela.setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Login inválido");
                }
            }
        });
    }

    public static void main(String[] args) {
        LogintelaExb frame = new LogintelaExb();
        frame.setVisible(true);
    }
}
