package p4.ExercicioB;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TarefasTelaExb extends JFrame {
    private JTextField campoTarefa;
    private DefaultListModel<String> modeloListaTarefas;

    public TarefasTelaExb() {
        setTitle("Gerenciamento de Tarefas");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel lblTarefa = new JLabel("Tarefa:");
        lblTarefa.setBounds(10, 10, 80, 25);
        getContentPane().add(lblTarefa);

        campoTarefa = new JTextField();
        campoTarefa.setBounds(100, 10, 160, 25);
        getContentPane().add(campoTarefa);

        JButton btnAdicionarTarefa = new JButton("Adicionar Tarefa");
        btnAdicionarTarefa.setBounds(270, 10, 120, 25);
        getContentPane().add(btnAdicionarTarefa);

        modeloListaTarefas = new DefaultListModel<>();
        JList<String> listaTarefas = new JList<>(modeloListaTarefas);
        JScrollPane painelRolagem = new JScrollPane(listaTarefas);
        painelRolagem.setBounds(10, 50, 380, 150);
        getContentPane().add(painelRolagem);

        JButton btnRemoverTarefa = new JButton("Remover Tarefa");
        btnRemoverTarefa.setBounds(10, 210, 380, 25);
        getContentPane().add(btnRemoverTarefa);

        btnAdicionarTarefa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String tarefa = campoTarefa.getText();
                if (!tarefa.isEmpty()) {
                    modeloListaTarefas.addElement(tarefa);
                    campoTarefa.setText("");
                }
            }
        });

        btnRemoverTarefa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int indiceSelecionado = listaTarefas.getSelectedIndex();
                if (indiceSelecionado != -1) {
                    modeloListaTarefas.remove(indiceSelecionado);
                }
            }
        });
    }
}
