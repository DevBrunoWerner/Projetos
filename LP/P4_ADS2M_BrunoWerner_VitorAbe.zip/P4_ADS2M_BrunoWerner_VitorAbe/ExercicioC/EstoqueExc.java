package p4.ExercicioC;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EstoqueExc extends JFrame {

    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField txtNome, txtPreco, txtQuantidade, txtFornecedor;

    public EstoqueExc() {
        setTitle("Gerenciamento de Estoque");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        getContentPane().add(panel, BorderLayout.CENTER);

        tableModel = new DefaultTableModel(new Object[]{"Nome", "Preço", "Quantidade", "Fornecedor"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        panel.add(inputPanel, BorderLayout.SOUTH);

        JLabel lblNome = new JLabel("Nome:");
        txtNome = new JTextField();
        JLabel lblPreco = new JLabel("Preço:");
        txtPreco = new JTextField();
        JLabel lblQuantidade = new JLabel("Quantidade:");
        txtQuantidade = new JTextField();
        JLabel lblFornecedor = new JLabel("Fornecedor:");
        txtFornecedor = new JTextField();

        inputPanel.add(lblNome);
        inputPanel.add(txtNome);
        inputPanel.add(lblPreco);
        inputPanel.add(txtPreco);
        inputPanel.add(lblQuantidade);
        inputPanel.add(txtQuantidade);
        inputPanel.add(lblFornecedor);
        inputPanel.add(txtFornecedor);

        JButton btnAdicionar = new JButton("Adicionar Produto");
        btnAdicionar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                adicionarProduto();
            }
        });
        inputPanel.add(btnAdicionar);

        setVisible(true);
    }

    private void adicionarProduto() {
        String nome = txtNome.getText();
        String preco = txtPreco.getText();
        String quantidade = txtQuantidade.getText();
        String fornecedor = txtFornecedor.getText();

        tableModel.addRow(new Object[]{nome, preco, quantidade, fornecedor});

        txtNome.setText("");
        txtPreco.setText("");
        txtQuantidade.setText("");
        txtFornecedor.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new EstoqueExc();
            }
        });
    }
}
