package p4.ExercicioC;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegistroDeVendasExc extends JFrame {

    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField txtQuantidade;
    private JComboBox<String> cmbMetodoPagamento;

    public RegistroDeVendasExc(DefaultTableModel estoqueTableModel) {
        setTitle("Registro de Vendas");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        getContentPane().add(panel, BorderLayout.CENTER);

        tableModel = new DefaultTableModel(new Object[]{"Nome", "Preço", "Quantidade", "Fornecedor"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel(new GridLayout(2, 2));
        panel.add(inputPanel, BorderLayout.SOUTH);

        JLabel lblQuantidade = new JLabel("Quantidade:");
        txtQuantidade = new JTextField();
        JLabel lblMetodoPagamento = new JLabel("Método de Pagamento:");
        cmbMetodoPagamento = new JComboBox<>(new String[]{"Dinheiro", "Cartão de Crédito", "Cartão de Débito"});

        inputPanel.add(lblQuantidade);
        inputPanel.add(txtQuantidade);
        inputPanel.add(lblMetodoPagamento);
        inputPanel.add(cmbMetodoPagamento);

        JButton btnRegistrarVenda = new JButton("Registrar Venda");
        btnRegistrarVenda.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrarVenda(estoqueTableModel);
            }
        });
        inputPanel.add(btnRegistrarVenda);

        setVisible(true);
    }

    private void registrarVenda(DefaultTableModel estoqueTableModel) {
        JOptionPane.showMessageDialog(this, "Venda registrada com sucesso!");

        txtQuantidade.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                DefaultTableModel estoqueTableModel = new DefaultTableModel(new Object[]{"Nome", "Preço", "Quantidade", "Fornecedor"}, 0);
                JTable estoqueTable = new JTable(estoqueTableModel);
                new RegistroDeVendasExc(estoqueTableModel);
            }
        });
    }
}
